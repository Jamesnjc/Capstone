import React from 'react'

export default function IconArrowLeft_svg() {
    return (
        <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 264.26 134.54">
            <title>Arrow_Left</title>
            <path d="M127.34,252.21v36.67L43.63,221.56l83.57-67.23v36.24H307.9v61.64Z"
                transform="translate(-43.63 -154.33)" />
        </svg>
    )
}

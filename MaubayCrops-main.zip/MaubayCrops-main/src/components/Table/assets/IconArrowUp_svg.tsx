import React from 'react'

export default function IconArrowUp_svg() {
    return (
        <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 134.87 264.08">
            <title>Arrow_Up</title>
            <path d="M161.93,310.66V130.49H125.15l67.47-83.91L260,130.36h-36.7v180.3Z"
                transform="translate(-125.15 -46.58)" />
        </svg>
    )
}

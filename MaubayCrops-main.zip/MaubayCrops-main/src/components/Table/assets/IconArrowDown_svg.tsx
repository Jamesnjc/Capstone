import React from 'react'

export default function IconArrowDown_svg() {
    return (
        <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 134.87 264.08">
            <title>Arrow_Down</title>
            <path d="M223.23,46.58V226.75H260c-22.72,28.24-45,55.91-67.48,83.91l-67.39-83.79h36.7V46.58Z"
                transform="translate(-125.15 -46.58)" />
        </svg>
    )
}
